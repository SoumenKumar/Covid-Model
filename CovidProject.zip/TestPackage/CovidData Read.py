from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import lmfit
from lmfit.lineshapes import gaussian, lorentzian
import matplotlib.cm as cm
import mplcursors
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import math
from sklearn.metrics import r2_score
import warnings
warnings.filterwarnings('ignore')


# filepath='E:\\Soumen_Education\\Research\\Covid\\2021\\WorldData.csv'
filepath='E:\\Soumen_Education\\Research\\Covid\\2021\\covid_19_data.csv'
pd.set_option("display.max_rows", 1000, "display.max_columns", None)
df_world=pd.read_csv(filepath)
df_world['Date'] = pd.to_datetime(df_world['ObservationDate'])
df_India=df_world[df_world['Country/Region'] == 'US']
# print(df_India.shape)
df_India.drop(['Country/Region', 'Province/State','SNo','Last Update'],axis=1,inplace=True)

# print(df_India)
df_India_MarApr=df_India[(df_India['Date'] >= '2020-03-01') & (df_India['Date'] <= '2020-05-30')]

# print(df_India_MarApr)
# quit()
df1=df_India_MarApr.groupby('Date').sum()
df1.reset_index(inplace=True)
# df_World=df_India[(df_India['ObservationDate'] >= '03/01/2021') & (df_India['ObservationDate'] <= '04/01/2021')]
print(df1)
# India_Infect=df_India_MarApr['Confirmed']
# India_Dead=df_India_MarApr['Deaths']
# India_Cure=df_India_MarApr['Recovered']
# print('Confirmed')
# print(India_Infect)
# print('Deaths')
# print(India_Dead)
# print('Recovered')
# print(India_Cure)