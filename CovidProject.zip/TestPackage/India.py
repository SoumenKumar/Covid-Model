from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import lmfit
from lmfit.lineshapes import gaussian, lorentzian
import matplotlib.cm as cm
import mplcursors
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import math
from sklearn.metrics import r2_score
import warnings
warnings.filterwarnings('ignore')





def plotseird(t, S, E, I, R,A, Q, F, India_Death, India_Infected,  D=None, L=None, R0=None, Alpha=None, CFR=None):
    f, ax = plt.subplots(1, 1, figsize=(12, 5))

    # ax.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
    # ax.plot(t,E , 'm',  alpha=0.7, linewidth=2, label='Exposed')
    ax.plot(t, India_Infected, 'b', alpha=0.7, linewidth=2, label='Actual_Infected')
    ax.plot(t, I, 'r', alpha=0.7, linewidth=2, label=' Model Predicted Infected')
    ax.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
    ax.plot(t, A, 'y', alpha=0.7, linewidth=2, label='Asymptomatic')
    ax.plot(t, Q, 'b', alpha=0.7, linewidth=2, label='Quarantined')
    ax.plot(t, F, 'k', alpha=0.7, linewidth=2, label='Model Predicted Death')
    ax.plot(t, India_Death, 'c--', alpha=0.7, linewidth=2, label='Actual_Death')

    if D is not None:
        ax.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
        # ax.plot(t, S + E + I + R + D, 'c--', alpha=0.7, linewidth=2, label='Total')
    # else:
        # ax.plot(t, S + E + I + R, 'c--', alpha=0.7, linewidth=2, label='Total')

    ax.set_xlabel('Time (days)')
    ax.set_ylabel('Persons')
    # ax = plt.gca()
    # ax.set_yticklabels(ax.get_yticks())

    ax.yaxis.set_tick_params(length=0)
    ax.xaxis.set_tick_params(length=0)
    ax.grid(b=True, which='major', c='w', lw=2, ls='-')
    legend = ax.legend(borderpad=2.0)
    legend.get_frame().set_alpha(0.5)

    for spine in ('top', 'right', 'bottom', 'left'):
        ax.spines[spine].set_visible(True)
    if L is not None:
        plt.title("Lockdown after {} days".format(L))
    mplcursors.cursor()
    plt.show();

    if R0 is not None or CFR is not None:
        f = plt.figure(figsize=(12, 4))

    if R0 is not None:
        # sp1
        ax1 = f.add_subplot(121)
        ax1.plot(t, R0, 'b--', alpha=0.7, linewidth=2, label='R_0')

        ax1.set_xlabel('Time (days)')
        ax1.title.set_text('R_0 over time')
        # ax.set_ylabel('Number (1000s)')
        ax.set_ylim(0,100000)
        ax1.yaxis.set_tick_params(length=0)
        ax1.xaxis.set_tick_params(length=0)
        ax1.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax1.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(False)

    if Alpha is not None:
        # sp2
        ax2 = f.add_subplot(122)
        ax2.plot(t, Alpha, 'r--', alpha=0.7, linewidth=2, label='alpha')

        ax2.set_xlabel('Time (days)')
        ax2.title.set_text('fatality rate over time')
        # ax.set_ylabel('Number (1000s)')
        # ax.set_ylim(0,1.2)
        ax2.yaxis.set_tick_params(length=0)
        ax2.xaxis.set_tick_params(length=0)
        ax2.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax2.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(True)


        plt.show();

def deriv(y, t, N, beta,alpha,phi, gamma, theta,delta,p,q,v):
    S, E, I, R,A, Q,F = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dAdt= alpha*(1.0-p)*E-phi*A
    dIdt = alpha*p*E + phi*(1.0-q)*A - gamma * I
    dQdt=gamma*I - theta*(1.0-v)*Q - delta*v*Q
    dRdt = phi*q*A + theta*(1.0-v)*Q
    dFdt=delta*v*Q

    # print("dSdt-->"+str(dSdt))
    # print("dEdt-->" + str(dEdt))
    # print("dAdt-->" + str(dAdt))
    # print("dIdt-->" + str(dIdt))
    # print("dQdt-->" + str(dQdt))
    # print("dRdt-->" + str(dRdt))

    # return dSdt, dEdt, dIdt, dRdt,
    return dSdt, dEdt, dIdt, dRdt, dAdt, dQdt, dFdt


filepath='E:\\Soumen_Education\\Research\\Covid\\covid_19_india.csv'
df_india=pd.read_csv(filepath)
print(df_india.shape)
print("Checking Data-type of each column:\n",df_india.dtypes)
df_india['Date'] = pd.to_datetime(df_india['Date'],dayfirst=True)
df_india.drop(['Sno', 'Time'],axis=1,inplace=True)

# collect present data
from datetime import date
# data_apr = df_india[df_india['Date'] > pd.Timestamp(date(2021,1,25)) & df_india['Date'] < pd.Timestamp(date(2021,2,25))]
data_apr = df_india[(df_india['Date'] > '2021-01-04') & (df_india['Date'] < '2021-02-04') ]
df1=data_apr.groupby('Date').sum()
df1.reset_index(inplace=True)
print(df1)
infect=df1['Confirmed']
print(infect)
quit()

N = 1300000000
# D = 50.0 # infections lasts 4 days
D = 4.65 # infections lasts 6 days
gamma = 1.0 /4.65
# gamma=0.2
alpha = 1.0 /3.75 # incubation period of 14  days
R_0 = 1.72
beta = R_0 * gamma  # R_0 = beta / gamma, so beta = R_0 * gamma
delta= 1.0/14# People dies within 12 days from Q.
phi=1.0/12.0  # within 10 days A will become either Infected (I) or Recovered (R)
theta= 1.0/10.0   # On an average if people spend 10 days to recover from Q to R
p= 0.75 # % of exposed (E) are symptomatic, rest (1-p) are asymptomatic
q= 0.8 # % of asymptomatic gets recovered automatically
v= 0.012 # % is the mortality rate

  # West Bengal : S0, E0, I0, R0, A0, Q0, F0 = N-5000.0, 3000.0, 1259.0, 220.0, 400.0, 700.0, 133.0  # initial conditions: one exposed
S0, E0, I0, R0, A0, Q0, F0 = N-700000.0, 100000.0, 46433.0, 60000.0, 60000.0, 30000.0, 1568.0  # initial conditions: one exposed


t = np.linspace(0,299,300) # Grid of time points (in days)
y0 = S0, E0, I0, R0,A0,Q0,F0# Initial conditions vector

# Integrate the SIR equations over the time grid, t.
# print('beta-->'+str(beta))
ret = odeint(deriv, y0, t, args=(N, beta,alpha, phi, gamma, theta,delta,p,q,v))
# S, E, I, R, A, Q, F = ret.T
S, E, I, R,A,Q,F = ret.T
print(I)

India_Death=[1568,1694,1783,1886,1981,2109,2206,2293,2415,2549,2649,2752,2872,3029,3163,3303,3435,3583,3720,3867,4021,4167,4337,4531,4706,4971,5164,5394,5598,5815,6075,6348,6642,6929,7135,7466,7745,8102,8498,8884,9195,9520,9900,11903,12237,12573,12948,13254,13699,14011,14476,14894,15301,15685,16095,16475,16893,17400,17834,18213,18655,19268,19693,20160,20642,21129]
India_Infected=[46433,49391,52952,56342,59662,62939,67152,70756,74281,78003,81970,85940,90927,96169,101139,106750,112359,118447,125101,131868,138845,145380,151767,158333,165799,173763,182143,190535,198706,207615,216919,226770,236657,246628,256611,266598,276583,286579,297535,308993,320922,332424,343091,354065,366946,380532,395048,410461,425282,440215,456183,473105,490401,508953,528859,548318,566840,585493,604641,625544,648315,673165,697413,719665,742417,767296]

print('Mean Absolute Err-->'+str(mean_absolute_error(India_Infected,I)))
RMSE=math.sqrt(mean_squared_error(India_Infected,I))
print("RMSE-->"+str(RMSE))
print("r2_score-->"+str(r2_score(India_Infected,I)))
plotseird(t, S, E, I, R,A,Q,F,India_Death,India_Infected)
# plotseird(t, S, E, I, R,A,Q,F)

# MAPE=np.mean(np.abs((India_Death - F) / India_Death)) * 100
print("MAPE-->"+str(MAPE))
