
def fibonacci(n):
    a = 0
    b = 1
    sum=0
    if n <= 0:
        print("Incorrect input")
    elif n == 1:
        return b
    else:
        for i in range(2, n):
            c = a + b
            a = b
            b = c
            sum=sum+c
            print('a-->'+str(a))
            print('b-->'+str(b))
            print('c-->'+str(c))
        return sum


# Driver Program

print(fibonacci(6))