from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import lmfit
from lmfit.lineshapes import gaussian, lorentzian
import matplotlib.cm as cm

import warnings
warnings.filterwarnings('ignore')

covid_data = pd.read_csv("E:\\Soumen_Education\\Research\\Covid\\westBengal.csv", skiprows=[1])
# print(covid_data)
data=covid_data['Deaths'].values[:]
print(data)
# quit()

def plotseird(t, S, E, I, R,A, Q, F, D=None, L=None, R0=None, Alpha=None, CFR=None):
    f, ax = plt.subplots(1, 1, figsize=(10, 4))
    # ax.imshow(f, cmap=cm.jet, interpolation='nearest')
    ax.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
    ax.plot(t, E, 'y', alpha=0.7, linewidth=2, label='Exposed')
    ax.plot(t, I, 'r', alpha=0.7, linewidth=2, label='Infected')
    ax.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
    ax.plot(t, A, 'm', alpha=0.7, linewidth=2, label='Asymptomatic')
    ax.plot(t, Q, 'o', alpha=0.7, linewidth=2, label='Quarantined')
    ax.plot(t, F, 'c--', alpha=0.7, linewidth=2, label='Fatal')
    if D is not None:
        ax.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
        # ax.plot(t, S + E + I + R + D, 'c--', alpha=0.7, linewidth=2, label='Total')
    # else:
        # ax.plot(t, S + E + I + R, 'c--', alpha=0.7, linewidth=2, label='Total')

    ax.set_xlabel('Time (days)')

    ax.yaxis.set_tick_params(length=0)
    ax.xaxis.set_tick_params(length=0)
    ax.grid(b=True, which='major', c='w', lw=2, ls='-')
    legend = ax.legend(borderpad=2.0)
    legend.get_frame().set_alpha(0.5)
    for spine in ('top', 'right', 'bottom', 'left'):
        ax.spines[spine].set_visible(False)
    if L is not None:
        plt.title("Lockdown after {} days".format(L))
    plt.show();

    if R0 is not None or CFR is not None:
        f = plt.figure(figsize=(12, 4))

    if R0 is not None:
        # sp1
        ax1 = f.add_subplot(121)
        ax1.plot(t, R0, 'b--', alpha=0.7, linewidth=2, label='R_0')

        ax1.set_xlabel('Time (days)')
        ax1.title.set_text('R_0 over time')
        # ax.set_ylabel('Number (1000s)')
        # ax.set_ylim(0,1.2)
        ax1.yaxis.set_tick_params(length=0)
        ax1.xaxis.set_tick_params(length=0)
        ax1.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax1.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(False)

    if Alpha is not None:
        # sp2
        ax2 = f.add_subplot(122)
        ax2.plot(t, Alpha, 'r--', alpha=0.7, linewidth=2, label='alpha')

        ax2.set_xlabel('Time (days)')
        ax2.title.set_text('fatality rate over time')
        # ax.set_ylabel('Number (1000s)')
        # ax.set_ylim(0,1.2)
        ax2.yaxis.set_tick_params(length=0)
        ax2.xaxis.set_tick_params(length=0)
        ax2.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax2.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(False)

        plt.show();

def deriv(y, t, N, beta,alpha,phi, gamma, x,delta,p,q,v):
    S, E, I, R,A, Q,F = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dAdt= alpha*(1.0-p)*E-phi*A
    dIdt = alpha*p*E + phi*(1.0-q)*A - gamma * I
    dQdt=gamma*I - x*(1.0-v)*Q - delta*v*Q
    dRdt = phi*q*A + x*(1.0-v)*I
    dFdt=delta*v*Q
    #
    # print("dSdt-->"+str(dSdt))
    # print("dEdt-->" + str(dEdt))
    # # print("dAdt-->" + str(dAdt))
    # print("dIdt-->" + str(dIdt))
    # # print("dQdt-->" + str(dQdt))
    # print("dRdt-->" + str(dRdt))

    # return dSdt, dEdt, dIdt, dRdt,
    return dSdt, dEdt, dIdt, dRdt, dAdt, dQdt, dFdt


def Model(days,p,q,R_0):
    N = 10000000
    D = 12.0  # infections lasts 4 days
    gamma = 1.0 / D
    alpha = 1.0 / 14.0  # incubation period of 14  days
    # R_0 = 15.0
    beta = R_0 * gamma  # R_0 = beta / gamma, so beta = R_0 * gamma
    delta = 1.0 / 2.0  # People dies within 6 days from Q.
    phi = 1.0 / 10.0  # within 10 days A will become either Infected (I) or Recovered (R)
    x = 1.0 / 12.0  # On an average if people spend 12 days to recover from Q to R
    # p = 0.6  # 40% of exposed (E) are symptomatic, rest (1-p) are asymptomatic
    # q = 0.6  # 80% of asymptomatic gets recovered automatically
    v = 0.05  # 5% is the mortality rate

    S0, E0, I0, R0, A0, Q0, F0 = N - 1.0, 10.0, 1.0, 0.0, 0.0, 0.0, 0.0  # initial conditions: one exposed

    t = np.linspace(0, 99, 100)  # Grid of time points (in days)
    y0 = S0, E0, I0, R0, A0, Q0, F0  # Initial conditions vector

    # Integrate the SIR equations over the time grid, t.
    # print('beta-->' + str(beta))
    ret = odeint(deriv, y0, t, args=(N, beta, alpha, phi, gamma, x, delta, p, q, v))
    # S, E, I, R, A, Q, F = ret.T
    S, E, I, R, A, Q, F = ret.T
    # print(F)
    return (t, S, E, I, R, A, Q, F)
    # plotseird(t, S, E, I, R,A,Q,F)


outbreak_shift = 0
params_init_min_max = {"R_0": (3.0, 1.0, 20.0), "p": (0.3, 0.1, 0.9), "q": (0.5,0.1, 0.9)}  # form: {parameter: (initial guess, minimum value, max value)}

days = outbreak_shift + len(data)
if outbreak_shift >= 0:
    y_data = np.concatenate((np.zeros(outbreak_shift), data))
else:
    y_data = data[-outbreak_shift:]

x_data = np.linspace(0, days - 1, days, dtype=int)
print(y_data)
print(x_data)
def fitter(x, p,q,R_0):
    ret = Model(days, p ,q,R_0)
    return ret[6][x]

mod = lmfit.Model(fitter)

for kwarg, (init, mini, maxi) in params_init_min_max.items():
    mod.set_param_hint(str(kwarg), value=init, min=mini, max=maxi, vary=True)

params = mod.make_params()
fit_method = "leastsq"
result = mod.fit(y_data, params, method="least_squares", x=x_data)
result.plot_fit(datafmt="-")
print(result.best_values)