from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import lmfit
from lmfit.lineshapes import gaussian, lorentzian
import matplotlib.cm as cm
import mplcursors
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import math
from sklearn.metrics import r2_score
import warnings
warnings.filterwarnings('ignore')



#old code for data reading starts

# filepath='E:\\Soumen_Education\\Research\\Covid\\covid_19_india.csv'
# df_india=pd.read_csv(filepath)
# # print(df_india.shape)
# # print("Checking Data-type of each column:\n",df_india.dtypes)
# df_india['Date'] = pd.to_datetime(df_india['Date'],dayfirst=True)
# df_india.drop(['Sno', 'Time'],axis=1,inplace=True)
#
# # collect present data
# from datetime import date
# # data_apr = df_india[df_india['Date'] > pd.Timestamp(date(2021,1,25)) & df_india['Date'] < pd.Timestamp(date(2021,2,25))]
# data_apr = df_india[(df_india['Date'] >= '2021-03-01') & (df_india['Date'] <= '2021-05-15') ]
# df1=data_apr.groupby('Date').sum()
# df1.reset_index(inplace=True)

#old code for data reading ends
# def plotseird(t, S, E, I, R,A, Q, F, India_Dead, India_Infect,  D=None, L=None, R0=None, Alpha=None, CFR=None):


def plotseird(t, S, E, I, R,A, Q, F, D=None, L=None, R0=None, Alpha=None, CFR=None):
    f, ax = plt.subplots(1, 1, figsize=(12, 5))

    ax.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
    ax.plot(t,E , 'g',  alpha=0.7, linewidth=2, label='Exposed')
    # ax.plot(t, India_Infect, 'b', alpha=0.7, linewidth=2, label='Actual_Infected')
    ax.plot(t, I, 'r', alpha=0.7, linewidth=2, label=' Model Predicted Infected')
    ax.plot(t, R, 'c', alpha=0.7, linewidth=2, label='Recovered')
    ax.plot(t, A, 'y', alpha=0.7, linewidth=2, label='Asymptomatic')
    ax.plot(t, Q, 'm', alpha=0.7, linewidth=2, label='Quarantined')
    ax.plot(t, F, 'k', alpha=0.7, linewidth=2, label='Model Predicted Death')
    # ax.plot(t, India_Dead, 'k', alpha=0.7, linewidth=2, label='Actual_Death')

    if D is not None:
        ax.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
        # ax.plot(t, S + E + I + R + D, 'c--', alpha=0.7, linewidth=2, label='Total')
    # else:
        # ax.plot(t, S + E + I + R, 'c--', alpha=0.7, linewidth=2, label='Total')

    ax.set_xlabel('Time (days)')
    ax.set_ylabel('Persons')
    ax = plt.gca()
    ax.set_yticklabels(ax.get_yticks())

    ax.yaxis.set_tick_params(length=0)
    ax.xaxis.set_tick_params(length=0)
    ax.grid(b=True, which='major', c='w', lw=2, ls='-')
    legend = ax.legend(borderpad=2.0)
    legend.get_frame().set_alpha(0.5)

    for spine in ('top', 'right', 'bottom', 'left'):
        ax.spines[spine].set_visible(True)
    if L is not None:
        plt.title("Lockdown after {} days".format(L))
    mplcursors.cursor()
    plt.show();

    if R0 is not None or CFR is not None:
        f = plt.figure(figsize=(12, 4))

    if R0 is not None:
        # sp1
        ax1 = f.add_subplot(121)
        ax1.plot(t, R0, 'b--', alpha=0.7, linewidth=2, label='R_0')

        ax1.set_xlabel('Time (days)')
        ax1.title.set_text('R_0 over time')
        # ax.set_ylabel('Number (1000s)')
        ax.set_ylim(0,100000)
        ax1.yaxis.set_tick_params(length=0)
        ax1.xaxis.set_tick_params(length=0)
        ax1.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax1.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(False)



        plt.show();

def deriv(y, t, N, beta,alpha,phi, gamma, theta,delta,p,q,v):
    S, E, I, R,A, Q,F = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dAdt= alpha*(1.0-p)*E-phi*A
    dIdt = alpha*p*E + phi*(1.0-q)*A - gamma * I
    dQdt=gamma*I - theta*(1.0-v)*Q - delta*v*Q
    dRdt = phi*q*A + theta*(1.0-v)*Q
    dFdt=delta*v*Q


    return dSdt, dEdt, dIdt, dRdt, dAdt, dQdt, dFdt

def soumenplotDead(t,F,India_Dead):


    plt.plot(t, India_Dead, 'b', alpha=0.7, linewidth=2, label='Actual_Fatal')
    plt.plot(t, F, 'r', alpha=0.7, linewidth=2, label=' Model Predicted Fatal')
    plt.xlabel('Time (days)')
    plt.ylabel('No Of person ')
    plt.show()

def soumenplotInfect(t,I,India_Infect):


    plt.plot(t, India_Infect, 'b', linewidth=2, label='Actual_Fatal')
    plt.plot(t, I, 'r', linewidth=2, label=' Model Predicted Fatal')
    plt.xlabel('Time (days)')
    plt.ylabel('No Of person ')
    plt.show()

filepath='C:\\Users\\Soumen Kumar\\PycharmProjects\\TestProject\\Data\\covid_19_data.csv'

def CountryData(country, startdate, enddate):
    df_world=pd.read_csv(filepath)
    pd.set_option("display.max_rows", 1000, "display.max_columns", None)
    df_world['Date'] = pd.to_datetime(df_world['ObservationDate'])
    df_India=df_world[df_world['Country/Region'] == country]
    # print(df_India.shape)
    df_India.drop(['Country/Region', 'Province/State','SNo','Last Update'],axis=1,inplace=True)

    # print(df_India)
    df_India_MarApr=df_India[(df_India['Date'] >= startdate) & (df_India['Date'] <= enddate)]
    df1=df_India_MarApr.groupby('Date').sum()
    df1.reset_index(inplace=True)
    # df_World=df_India[(df_India['ObservationDate'] >= '03/01/2021') & (df_India['ObservationDate'] <= '04/01/2021')]
    # print(df1)
    return(df1)



country='UK'
startdate='2020-09-10'
enddate='2021-05-30'




df1=CountryData(country,startdate,enddate)
# print('Country Data-->'+country)
# print(df1)
# quit()

India_Infect=df1['Confirmed']
India_Dead=df1['Deaths']
India_Cure=df1['Recovered']
# print(India_Infect)

N = 68000000
# D = 50.0 # infections lasts 4 days
# D = 50.0 # infections lasts 4 days
D = 5 # infections lasts 6 days
gamma = 1/22
# gamma=0.2
alpha = 1.0/21# incubation period of 14  days
R_0 =2.9
beta = R_0 * gamma  # R_0 = beta / gamma, so beta = R_0 * gamma
delta= 1.0/18 # People dies within 12 days from Q.
phi= 1/16# within 10 days A will become either Infected (I) or Recovered (R)
theta= 1.0/12  # On an average if people spend 10 days to recover from Q to R
p= 0.6# % of exposed (E) are symptomatic, rest (1-p) are asymptomatic
q= 0.55 # % of asymptomatic gets recovered automatically
v= 0.0095# % is the mortality rate

# S0, E0, I0, R0, A0, Q0, F0 = 60000000, 1000000.0, 340546.0, 1847.0, 80000.0, 70000.0,41697.0
S0, E0, I0, R0, A0, Q0, F0 = 60000000, 1000000.0, 340546.0, 1847.0, 80000.0, 70000.0,41697.0
# 1000000

# # #US-2nd wave( 1st Mar to 15th April)
# S0, E0, I0, R0, A0, Q0, F0 = 300000000, 150000.0, 76.0, 7.0, 7500.0, 500.0, 1.0


t = np.linspace(0,350,351) # Grid of time points (in days)
y0 = S0, E0, I0, R0,A0,Q0,F0# Initial conditions vector

# Integrate the SIR equations over the time grid, t.
# print('beta-->'+str(beta))
ret = odeint(deriv, y0, t, args=(N, beta,alpha, phi, gamma, theta,delta,p,q,v))
# S, E, I, R, A, Q, F = ret.T
S, E, I, R,A,Q,F = ret.T





# print('India_Infected')
# print(I)
# # print(E)
# MAPE_Infect=np.mean(np.abs((India_Infect -I) / India_Infect)) * 100
# print("MAPE Infected-->"+str(MAPE_Infect))
# print("r2_score Infected-->"+str(r2_score(I,India_Infect)))
# # quit()
# soumenplotInfect(t,np.array(I),np.array(India_Infect))
#
#
# print(India_Dead)
# print(F)
# MAPE_Dead=np.mean(np.abs((India_Dead - F) / India_Dead)) * 100
# print("MAPE Dead-->"+str(MAPE_Dead))
# print("r2_score Dead-->"+str(r2_score(India_Dead,F)))
# soumenplotDead(t,np.array(F),np.array(India_Dead))
# # # # #
# plotseird(t, S, E, I, R,A,Q,F,India_Dead,India_Infect)
# print(I.shape)
# print(India_Dead.shape)



# # print('Mean Absolute Err-->'+str(mean_absolute_error(India_Infect,I)))
# RMSE=math.sqrt(mean_squared_error(India_Infect,I))
# print("RMSE-->"+str(RMSE))

# plotseird(t, S, E, I, R,A,Q,F,India_Death,India_Infected)
plotseird(t, S, E, I, R,A,Q,F)
#
# MAPE=np.mean(np.abs((India_Dead - F) / India_Dead)) * 100
# print("MAPED-->"+str(MAPE))


