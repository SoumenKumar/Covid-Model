
import matplotlib.pyplot as plt
import pandas as pd

import numpy as np
from math import *
# print(33==33.0)

# print(eval("1+3*2"))
# print(0.1+0.2)

# d={0,1,2}
# for x in d:
#     print(x,end="@")


# x='KLCSE'
# print(list(map(list,x)))

# print('abcd'.translate({'a':'1,','b':'2,','c':'3,','d':'4,'}))
# set1=set("KLH")
# set2=set("UNIVERSITY")
# print(set1-set2)

# a=4.13
# b=6.7777
# c=-8.12
# print(int(a),floor(b),ceil(c),fabs(c))

list1=["1","4","0","6","9","1"]
list1=[int(i) for i in list1]
list1.sort()
print(list1)



# list1=[1,3,5,6,7,8]
# list1.extend([2,4])
# print(list1)



# a={1:"k",2:"L",3:"H",4:"C"}
#
# for i,j in a.items():
#     print(j,end="-")

# a={1:["k","L","H"],2:"B",3:"C"}
# print(a.get(1,2))


# a={1:2,2:2,3:3,4:4}
# a.pop(0)
# print(a)


# a,b,c=6,7,8
# a,c,b=b,a,c
# print(a,b,c)

# print('klh cse ece'.title())
quit()

# Generate a sequence of numbers from -10 to 10 with 100 steps in between
x = np.linspace(-10, 10, 100)
# Create a second array using sine
y = np.sin(x)
# The plot function makes a line chart of one array against another
plt.plot(x, y, marker="x")
plt.show()
