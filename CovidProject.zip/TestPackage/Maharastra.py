from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import mplcursors
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import math
from sklearn.metrics import r2_score
import lmfit
from lmfit.lineshapes import gaussian, lorentzian
import matplotlib.cm as cm

import warnings
warnings.filterwarnings('ignore')


def plotseird(t, S, E, I, R,A, Q, F, MH_death, MH_Infected,  D=None, L=None, R0=None, Alpha=None, CFR=None):
    f, ax = plt.subplots(1, 1, figsize=(10, 4))

    # ax.plot(t, S, 'b', alpha=0.7, linewidth=2, label='Susceptible')
    # ax.plot(t,E , 'm',  alpha=0.7, linewidth=2, label='Exposed')
    ax.plot(t, MH_Infected, 'b', alpha=0.7, linewidth=2, label='Actual Infected')
    ax.plot(t, I, 'r', alpha=0.7, linewidth=2, label=' Model Predicted Infected')
    # ax.plot(t, R, 'g', alpha=0.7, linewidth=2, label='Recovered')
    # ax.plot(t, A, 'y', alpha=0.7, linewidth=2, label='Asymptomatic')
    # ax.plot(t, Q, 'b', alpha=0.7, linewidth=2, label='Quarantined')
    # ax.plot(t, F, 'k', alpha=0.7, linewidth=2, label='Model Predicted Death')
    # ax.plot(t, MH_death, 'c--', alpha=0.7, linewidth=2, label='Actual _Death')

    if D is not None:
        ax.plot(t, D, 'k', alpha=0.7, linewidth=2, label='Dead')
        # ax.plot(t, S + E + I + R + D, 'c--', alpha=0.7, linewidth=2, label='Total')
    # else:
        # ax.plot(t, S + E + I + R, 'c--', alpha=0.7, linewidth=2, label='Total')

    ax.set_xlabel('Time (days)')
    ax.set_ylabel('Persons')
    # ax = plt.gca()
    # ax.set_yticklabels(ax.get_yticks())

    ax.yaxis.set_tick_params(length=0)
    ax.xaxis.set_tick_params(length=0)
    ax.grid(b=True, which='major', c='w', lw=2, ls='-')
    legend = ax.legend(borderpad=2.0)
    legend.get_frame().set_alpha(0.5)
    for spine in ('top', 'right', 'bottom', 'left'):
        ax.spines[spine].set_visible(True)
    if L is not None:
        plt.title("Lockdown after {} days".format(L))
    mplcursors.cursor()
    plt.show();

    if R0 is not None or CFR is not None:
        f = plt.figure(figsize=(12, 4))

    if R0 is not None:
        # sp1
        ax1 = f.add_subplot(121)
        ax1.plot(t, R0, 'b--', alpha=0.7, linewidth=2, label='R_0')

        ax1.set_xlabel('Time (days)')
        ax1.title.set_text('R_0 over time')
        # ax.set_ylabel('Number (1000s)')
        ax.set_ylim(0,100000)
        ax1.yaxis.set_tick_params(length=0)
        ax1.xaxis.set_tick_params(length=0)
        ax1.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax1.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(False)

    if Alpha is not None:
        # sp2
        ax2 = f.add_subplot(122)
        ax2.plot(t, Alpha, 'r--', alpha=0.7, linewidth=2, label='alpha')

        ax2.set_xlabel('Time (days)')
        ax2.title.set_text('fatality rate over time')
        # ax.set_ylabel('Number (1000s)')
        # ax.set_ylim(0,1.2)
        ax2.yaxis.set_tick_params(length=0)
        ax2.xaxis.set_tick_params(length=0)
        ax2.grid(b=True, which='major', c='w', lw=2, ls='-')
        legend = ax2.legend()
        legend.get_frame().set_alpha(0.5)
        for spine in ('top', 'right', 'bottom', 'left'):
            ax.spines[spine].set_visible(True)

        mplcursors.cursor()
        plt.show();

def deriv(y, t, N, beta,alpha,phi, gamma, theta,delta,p,q,v):
    S, E, I, R,A, Q,F = y
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dAdt= alpha*(1.0-p)*E-phi*A
    dIdt = alpha*p*E + phi*(1.0-q)*A - gamma * I
    dQdt=gamma*I - theta*(1.0-v)*Q - delta*v*Q
    dRdt = phi*q*A + theta*(1.0-v)*Q
    dFdt=delta*v*Q

    # print("dSdt-->"+str(dSdt))
    # print("dEdt-->" + str(dEdt))
    # # print("dAdt-->" + str(dAdt))
    # print("dIdt-->" + str(dIdt))
    # # print("dQdt-->" + str(dQdt))
    # print("dRdt-->" + str(dRdt))

    # return dSdt, dEdt, dIdt, dRdt,
    return dSdt, dEdt, dIdt, dRdt, dAdt, dQdt, dFdt


N = 115000000
# D = 50.0 # infections lasts 4 days
D = 6.5 # infections lasts 6 days
gamma = 1.0 / 6.2
# gamma=0.2
alpha = 1.0 / 3.8 # incubation period of 14  days
R_0 = 1.93
beta = R_0 * gamma  # R_0 = beta / gamma, so beta = R_0 * gamma
delta= 1.0/14# People dies within 12 days from Q.
phi=1.0/14.0  # within 10 days A will become either Infected (I) or Recovered (R)
theta= 1.0/10.0   # On an average if people spend 10 days to recover from Q to R
p= 0.7 # % of exposed (E) are symptomatic, rest (1-p) are asymptomatic
q= 0.8 # % of asymptomatic gets recovered automatically
v= 0.021 # % is the mortality rate

  # West Bengal : S0, E0, I0, R0, A0, Q0, F0 = N-5000.0, 3000.0, 1259.0, 220.0, 400.0, 700.0, 133.0  # initial conditions: one exposed
S0, E0, I0, R0, A0, Q0, F0 = N-80000.0, 30000.0, 14541.0, 24650.0, 6000.0, 6000.0, 583.0  # initial conditions: one exposed


t = np.linspace(0,65,66) # Grid of time points (in days)
y0 = S0, E0, I0, R0,A0,Q0,F0# Initial conditions vector

# Integrate the SIR equations over the time grid, t.
# print('beta-->'+str(beta))
ret = odeint(deriv, y0, t, args=(N, beta,alpha, phi, gamma, theta,delta,p,q,v))
# S, E, I, R, A, Q, F = ret.T
S, E, I, R,A,Q,F = ret.T
print(I)
# WB_Actual_Death=[133,140,144,151,160,171,185,190,198,207,215,225,232,238,244,250,253,259,265,269,272,278,283,289,295,302,309,317,325,335,345,355,366,383,396,405,415,432,442,451,463,475,485,495,506,518,529,540,555,569,580,591,606,616,629,639,653,668,683,699,717,736,757,779,804,827]
# WB_ActualInfected=[1259,1344,1456,1548,1678,1786,1939,2063,2173,2290,2377,2461,2576,2677,2825,2961,3103,3197,3332,3459,3667,3816,4009,4192,4536,4813,5130,5501,5772,6168,6508,6876,7303,7738,8187,8613,8985,9328,9768,10244,10698,11087,11494,11909,12300,12735,13090,13531,13945,14358,14728,15173,15648,16190,16711,17283,17907,18559,19170,19819,20488,21231,22126,22987,23837,24823,25911]
MH_death=[583,617,651,694,731,779,832,868,921,975,1019,1068,1135,1198,1249,1325,1390,1454,1517,1577,1635,1695,1792,1897,1982,2098,2197,2286,2362,2465,2587,2710,2849,2969,3060,3169,3289,3438,3590,3717,3830,3950,4128,5537,5651,5751,5893,5984,6170,6283,6531,6739,6931,7106,7273,7429,7610,7855,8053,8178,8376,8671,8822,9026,9250,9448]
MH_Infected=[14541,15525,16758,17974,19063,20228,22171,23401,24427,25922,27524,29100,30706,33053,35058,37136,39297,41642,44582,47190,50231,52667,54758,56948,59546,62228,65168,67655,70013,72300,74860,77793,80229,82968,85975,88528,90787,94041,97648,101141,104568,107958,110744,113445,116752,120504,124331,128205,132075,135796,139010,142900,147741,152765,159133,164626,169883,174761,180298,186626,192990,200064,206619,211987,217121,223724]

print('Mean Absolute Err-->'+str(mean_absolute_error(MH_death,F)))
RMSE=math.sqrt(mean_squared_error(MH_death,F))
print("RMSE-->"+str(RMSE))
print("r2_score-->"+str(r2_score(MH_death,F)))
# plotseird(t, S, E, I, R,A,Q,F,MH_death,MH_Infected)
# plotseird(t, S, E, I, R,A,Q,F)


MAPE=np.mean(np.abs((MH_Infected - I) / MH_Infected)) * 100
print("MAPE-->"+str(MAPE))