import matplotlib.pyplot as plt
import numpy as np
import lmfit
from lmfit.lineshapes import gaussian, lorentzian

np.random.seed(10)
x = np.linspace(0, 20.0, 100)

data = (gaussian(x, 21, 6.1, 1.2))
# + np.random.normal(scale=0.1, size=x.size))  # normal distr. with some noise
plt.plot(x, data);
plt.show()